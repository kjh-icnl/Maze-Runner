"""
Copyright 2021.09.16 Jinhwi Kim
E-mail: miss2259@naver.com
This file is being protected by the copyright law.
Do not distribute this file to any third party without a developer's permission.
However, you can share the homepage you have downloaded this file with the third party
You can commercially take benefit after the developer's commercial permission.

You must not erase this announcement.
"""

import sys

def __check_map_data(data):
    left, right = 0, 0
    left_y, right_y = 0, 0
    for i, row in enumerate(data):
        #print(f'{row[0]} {row[-1]}')
        if row[0] == '0':
            left += 1
            left_y = i
        if row[-1] == '0':
            right += 1
            right_y = i
    if left == 1 and right == 1:
        return True, left_y, right_y
    else:
        return False, None, None

def _check_map_data(data):
    length = 0
    for idx, e in enumerate(data):
        if idx == 0:
            length = len(e)
            continue
        if length != len(e):
            return False
        length = len(e)
    if len(data) < 2 or len(data[0]) < 2:
        return False
    return True

def parse_map(map_file):
    try:
        with open(map_file, 'r') as f:
            _map = f.read()
    except FileNotFoundError:
        print(f'ERROR> Not Found File: {map_file}')
        sys.exit()

    _map = _map.splitlines()

    result, start_y, dst_y =  __check_map_data(_map)
    if _check_map_data(_map) and result:
        return _map, start_y, dst_y
    else:
        print(f'ERROR> Wrong File Contents: {map_file}')
        sys.exit()

def parse_canvas_size(map_file, w_scale = 36, h_scale = 37.5):
    with open(map_file, 'r') as f:
        data = f.read()
    data = data.splitlines()
    if _check_map_data(map_file):
        return f'{w_scale*len(data[0])}x{h_scale*len(data)}'
