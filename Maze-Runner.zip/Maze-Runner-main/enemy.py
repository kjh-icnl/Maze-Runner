import tkinter as tk
import math

reverse = {
    0: 1,
    1: 0,
    2: 3,
    3: 4
}

class LengthError(Exception):
    pass

class Enemy:
    def __init__(self, window, x, y) -> None:
        self._direction = -1 # Has no direction
        self._prev = None
        self._position = (x, y)
        self._image = tk.PhotoImage(file="img/devil.png") # User image loads
        self._label = tk.Label(window, image=self._image, bg="white")
        self._label.grid(row=y, column=x)
        self._actions = []
        self._back = False

    def get_enemy_position(self):
        """
        Return a tuple

        It has a form of (x, y).
        """
        return self._position

    def touch_east(self, map_data):
        """
        Return a boolean value

        return True if there is a wall at the east side.
        An enemy can try touching the wall.
        """
        try:
            if map_data[self._position[1]][self._position[0]+1] == '1':
                return True
        except IndexError:
            return None
        return False

    def touch_west(self, map_data):
        """
        Return a boolean value

        return True if there is a wall at the west side.
        An enemy can try touching the wall.
        """
        if self._position[0] <= 0:
            return None
        if map_data[self._position[1]][self._position[0]-1] == '1':
            return True
        return False

    def touch_south(self, map_data):
        """
        Return a boolean value

        return True if there is a wall at the south side.
        An enemy can try touching the wall.
        """
        try:
            if map_data[self._position[1]+1][self._position[0]] == '1':
                return True
        except IndexError:
            return None
        return False

    def touch_north(self, map_data):
        """
        Return a boolean value

        return True if there is a wall at the north side.
        An enemy can try touching the wall.
        """
        if self._position[1] == 0:
            return None
        if map_data[self._position[1]-1][self._position[0]] == '1':
            return True
        return False

    def get_distance(self, From):
        """
        Return a real number

        It is a distance from 'From' tuple to an enemy position.
        """
        if type(From) != tuple:
            raise TypeError('The type of the argument should be tuple.')
        if len(From) != 2:
            raise LengthError('The length of the tuple should be 2 because of x and y')

        dist = math.sqrt(abs(self._position[0]-From[0])**2 + abs(self._position[1]-From[1])**2)
        return dist
    
    def get_difference(self, From):
        """
        Return a tuple

        It has a positional difference and form of (x, y) from 'From' tuple to an enemy position.
        """
        if type(From) != tuple:
            raise TypeError('The type of the argument should be tuple.')
        if len(From) != 2:
            raise LengthError('The length of the tuple should be 2 because of x and y')

        return (self._position[0]-From[0], self._position[1]-From[1])

    def get_direction(self):
        """
        Return a numbeer from 0 to 3

        Each number means each direction.
        0 - East, 1 - West, 2 - South, 3 - North
        """
        if self._prev == None:
            return 0
        
        direction = self._position[0] - self._prev[0], self._position[1] - self._prev[1]
        if direction == (1, 0): #east
            return 0
        elif direction == (0, 1): #south
            return 2
        elif direction == (-1, 0): #west
            return 1
        elif direction == (0, -1): #north
            return 3

    def _move_east(self):
        self._prev = self._position
        self._position = (self._position[0]+1, self._position[1])
        self._direction = 0 #east
        self._label.grid(row=self._position[1], column=self._position[0])

    def _move_west(self):
        self._prev = self._position
        self._position = (self._position[0]-1, self._position[1])
        self._direction = 1 #west
        self._label.grid(row=self._position[1], column=self._position[0])
        
    def _move_south(self):
        self._prev = self._position
        self._position = (self._position[0], self._position[1]+1)
        self._direction = 2 #south
        self._label.grid(row=self._position[1], column=self._position[0])

    def _move_north(self):
        self._prev = self._position
        self._position = (self._position[0], self._position[1]-1)
        self._direction = 3 #north
        self._label.grid(row=self._position[1], column=self._position[0])

    def move(self, map_data):
        """
        This is a sample movement algorithm for an enemy.
        For a grading test, other movement policies will be apllied including this sample movement.
        """
        if len(self._actions) > 10 or self._back:
            now = self._actions.pop()
            if now == 0:
                self._move_west()
            elif now == 1:
                self._move_east()
            elif now == 2:
                self._move_north()
            elif now == 3:
                self._move_south()
            
            if len(self._actions) == 0:
                self._back = False
            return

        if len(self._actions) == 9:
            self._back = True

        if self._direction == 0: # head east        
            if self.touch_south(map_data) == False:
                self._move_south()
                self._actions.append(2)
                return
            
            if self.touch_east(map_data) == False:
                self._move_east()
                self._actions.append(0)
                return

            if self.touch_north(map_data) == False:
                self._move_north()
                self._actions.append(3)
                return
            
            if self.touch_west(map_data) == False:
                self._move_west()
                self._actions.append(1)
                return
            
        elif self._direction == 1: # head west
            if self.touch_north(map_data) == False:
                self._move_north()
                self._actions.append(3)
                return
            
            if self.touch_west(map_data) == False:
                self._move_west()
                self._actions.append(1)
                return

            if self.touch_south(map_data) == False:
                self._move_south()
                self._actions.append(2)
                return
            
            if self.touch_east(map_data) == False:
                self._move_east()
                self._actions.append(0)
                return

        elif self._direction == 2: # head south
            if self.touch_west(map_data) == False:
                self._move_west()
                self._actions.append(1)
                return

            if self.touch_south(map_data) == False:
                self._move_south()
                self._actions.append(2)
                return

            if self.touch_east(map_data) == False:
                self._move_east()
                self._actions.append(0)
                return
            
            if self.touch_north(map_data) == False:
                self._move_north()
                self._actions.append(3)
                return

        elif self._direction == 3: # head north
            if self.touch_east(map_data) == False:
                self._move_east()
                self._actions.append(0)
                return

            if self.touch_north(map_data) == False:
                self._move_north()
                self._actions.append(3)
                return
            
            if self.touch_west(map_data) == False:
                self._move_west()
                self._actions.append(1)
                return
            
            if self.touch_south(map_data) == False:
                self._move_south()
                self._actions.append(2)
                return

        else:
            if self.touch_east(map_data) == False:
                self._move_east()
                self._actions.append(0)
                return
            elif self.touch_west(map_data) == False:
                self._move_west()
                self._actions.append(1)
                return
            elif self.touch_south(map_data) == False:
                self._move_south()
                self._actions.append(2)
                return
            elif self.touch_north(map_data) == False:
                self._move_north()
                self._actions.append(3)
                return

def main():
    pass

if __name__ == '__main__':
    main()