import maze
import tkinter as tk
from parse import parse_canvas_size
import random

def run(obj):
    """
    Implement Your Algorithms Here
    Line 12 ~ 13 are an example
    
    ****** CAUTION ******
    You should implement an algorithm about how it detects if it reaches the destination.
    Although it invades the wall (black blocks), it does not occur any error.
    However, it will not be accepted as an answer.
    Therefore, your algorithm should be able to let it stop on a proper white block (destination).
    If it occurs an error of IndexError, your algorithm cannot be considered as an appropriate answer.


    ****** RULES ******
    1. There is no limitation about implementation. You can try anything you can implement (cheating is not allowed).
       -> You can import any library to utilize except for the modules related with solving a maze.
       -> If you import additionally external module(s), then you should let me know what modules you imports.
       -> You can add and modify any other functions to solve this problem in all files, 'main.py', 'maze.py', and 'parse.py'.
    2. Your implemenation should perform well about other invisible test cases except for the given samples.
       -> You can examine your codes by yourself as creating new maze maps (it is allowed).
       -> 
    3. The number of the test cases successfully done is most dominant for your rating.
    4. If some people have the identical number of them, a person who has the least turns will win the supremacy.


    ****** TIPS ******
    - You don't have to revise many things.
    - You can make your own algorithm even if filling this section.
    """
    
    for i in range(30):
        e = obj.touch_east()
        w = obj.touch_west()
        s = obj.touch_south()
        n = obj.touch_north()
        move = (e, w, s, n)

        while True:
            idx = random.randint(0, 3)
            # It does not move toward the wall side.
            if move[idx]:
                continue
            
            if idx == 0:
                obj.move_east()
                break

            if idx == 1:
                obj.move_west()
                break

            if idx == 2:
                obj.move_south()
                break

            if idx == 3:
                obj.move_north()
                break

def main():
    # Set a maze file
    #file_name = 'mazes/sample_maze1.o'
    file_name = 'mazes/sample_maze2.o'
    #file_name = 'mazes/sample_field.o'
    #file_name = 'mazes/sample_field2.o'
    resolution = parse_canvas_size(file_name)

    
    # Creation of a window and background
    # And setting of them
    root = tk.Tk()
    root.geometry(resolution)
    root.title("Maze Runner")
    root.resizable(True, True)
    icon = tk.PhotoImage(file="img/icon.png")
    root.iconphoto(True, icon)

    # Run creation of maze
    #_maze = maze.Maze(root, file_name, auto_exit = False) # _maze = maze.Maze(root, <your maze>)
    _maze = maze.Maze(root, file_name)

    # Run maze
    _maze.run(func=lambda: run(_maze))

    root.mainloop()

if __name__ == '__main__':
    main()
