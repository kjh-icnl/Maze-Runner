import tkinter as tk
from PIL import Image, ImageTk

import random, sys

import parse
from enemy import Enemy

count = 0 # Your turns

class WrongArgumentsError(Exception):
    pass


class Maze(Enemy):
    def __init__(self, window, given_map = None, auto_exit = True) -> None:
        """
        Initialize a maze.
        To do this, this function parses the given_map (maze file)
        and creates the window and background following it.
        """

        ##### Public Variables: Start #####
        self.x_len = 20
        self.y_len = 20
        self.start = (0, 0)
        self.dst = (0, 0)
        self.prev = None
        self.current = (0, 0)
        ###### Public Variables: End ######

        ##### Private Variables: Start #####
        self._root = window
        self._grids = [] # Private Data, You cannot access this data
        self._map_data ='' # Private Data, You cannot access this data.
        self._image = tk.PhotoImage(file="img/user.png") # User image loads
        self._empty = tk.PhotoImage(file="") # empty image
        self._actions = []
        self._auto_exit = auto_exit
        self._timer = 5

        if given_map == None:
            self._maze_create(window)
        else:
            self.__maze_create(window, given_map)

        self._label = tk.Label(window, image=self._image, bg="white")
        self._label.grid(row=self.start[1], column=self.start[0])

        # Multiple enemies
        # self._enemies = [Enemy(window, random.randint(1, 10), random.randint(1, 10)) for i in range(4)]
        self._enemies = [Enemy(window, pos[0], pos[1]) for pos in Maze._set_enemy(self._map_data, self.x_len, self.y_len)]

        # Single enemy
        #self._enemy = Enemy(window, self.dst[0], self.dst[1])

        # For a Game Over message.
        self.w = int(30*self.x_len)
        self.h = int(self.w//5.968)
        self._game_over = Image.open("img/game_over.png")
        self._game_over = self._game_over.resize((self.w, self.h))
        self._resized_over = ImageTk.PhotoImage(self._game_over)

        # Activation of a start button
        self._btn = tk.Button(text="Start")
        self._btn.grid(row=self.y_len+1, column=self.x_len//2 - 1, columnspan=2)
        ###### Private Data: End ######

        #self._over_check(window)

    def _run(self, func):
        print('[Play Log]')
        #print(f'Run: 123')
        func()
        self._btn['command'] = ''

    def run(self, func):
        """
        Return None

        It helps your algorithm code runned.
        """
        self._btn['command'] = lambda: self._run(func)

    def _move_east(self):
        info = self._label.grid_info()
        self._label.grid(row=info['row'], column=info['column']+1)
        
        self.prev = (info['column'], info['row'])
        self.current = (info['column']+1, info['row'])

        for enemy in self._enemies:
            enemy.move(self._map_data)
            #print(enemy.get_enemy_position())
        self._actions.pop(0)
        self._over_check()
        return True

    def move_east(self):
        """
        Return None

        Move one block toward east.
        """
        global count
        try:
            action = self._label.after(500*count, func = self._move_east)
            self._actions.append(action)
            self.prev = self.current
            self.current = (self.current[0]+1, self.current[1])
            count += 1
        except:
            pass
        return

    def _move_west(self):
        info = self._label.grid_info()
        self._label.grid(row=info['row'], column=info['column']-1)

        self.prev = (info['column'], info['row'])
        self.current = (info['column']-1, info['row'])

        for enemy in self._enemies:
            enemy.move(self._map_data)
        self._actions.pop(0)
        self._over_check()
        return True

    def move_west(self):
        """
        Return None

        Move one block toward west.
        """
        global count
        try:
            action = self._label.after(500*count, func = self._move_west)
            self._actions.append(action)
            self.prev = self.current
            self.current = (self.current[0]-1, self.current[1])
            count += 1
        except:
            pass
        return

    def _move_south(self):
        info = self._label.grid_info()
        self._label.grid(row=info['row']+1, column=info['column'])
        
        self.prev = (info['column'], info['row'])
        self.current = (info['column'], info['row']+1)

        for enemy in self._enemies:
            enemy.move(self._map_data)
        self._actions.pop(0)
        self._over_check()
        return True

    def move_south(self):
        """
        Return None

        Move one block toward south.
        """
        global count
        try:
            action = self._label.after(500*count, func = self._move_south)
            self._actions.append(action)
            self.prev = self.current
            self.current = (self.current[0], self.current[1]+1)
            count += 1
        except:
            pass
        return

    def _move_north(self):
        info = self._label.grid_info()
        self._label.grid(row=info['row']-1, column=info['column'])

        self.prev = (info['column'], info['row'])
        self.current = (info['column'], info['row']-1)

        for enemy in self._enemies:
            enemy.move(self._map_data)
        self._actions.pop(0)
        self._over_check()
        return True

    def move_north(self):
        """
        Return None

        Move one block toward north.
        """
        global count
        try:
            action = self._label.after(500*count, func = self._move_north)
            self._actions.append(action)
            self.prev = self.current
            self.current = (self.current[0], self.current[1]-1)
            count += 1
        except:
            pass
        return

    def touch_east(self):
        """
        Return Boolean

        Touch east. Return True if an east block is a wall (black block).
        Return False if an east block is a corridor (white block).
        """
        try:
            if self._map_data[self.current[1]][self.current[0]+1] == '1':
                return True
            else:
                return False
        except IndexError:
            return True
    
    def touch_west(self):
        """
        Return Boolean

        Touch west. Return True if a west block is a wall (black block).
        Return False if a west block is a corridor (white block).
        """
        if self.current[0]-1 < 0:
            return True
        if self._map_data[self.current[1]][self.current[0]-1] == '1':
            return True
        else:
            return False
    
    def touch_south(self):
        """
        Return Boolean

        Touch south. Return True if a south block is a wall (black block).
        Return False if a south block is a corridor (white block).
        """
        try:
            if self._map_data[self.current[1]+1][self.current[0]] == '1':
                return True
            else:
                return False
        except IndexError:
            return True
    
    def touch_north(self):
        """
        Return Boolean

        Touch north. Return True if a north block is a wall (black block).
        Return False if a north block is a corridor (white block).
        """
        if self.current[1]-1 < 0:
            return True
        if self._map_data[self.current[1]-1][self.current[0]] == '1':
            return True
        else:
            return False

    def get_direction(self):
        """
        Return a numbeer from 0 to 3

        Each number means each direction.
        0 - East, 1 - West, 2 - South, 3 - North
        """
        if self.prev == None:
            return 0
        
        direction = (self.current[0] - self.prev[0], self.current[1] - self.prev[1])
        #print(f'DIR {self.prev} {self.current}')
        if direction == (1, 0):
            return 0
        elif direction == (0, 1):
            return 2
        elif direction == (-1, 0):
            return 1
        elif direction == (0, -1):
            return 3

    def straight_end(self):
        """
        Return an integer number

        The return value means a distance from your user to the neareast wall toward your direction.
        At this time, your direction follows the return value of the function of 'get_direction'.
        """
        distance = 0
        if self.get_direction() == 0: #East
            for w in self._map_data[self.current[1]][self.current[0]+1:]:
                if w == '1':
                    return distance
                else:
                    distance += 1
                    continue
            return None
        elif self.get_direction() == 1: #West
            for w in self._map_data[self.current[1]][:self.current[0]]:
                if w == '1':
                    distance = 0
                else:
                    distance += 1
                    continue
            return distance
        elif self.get_direction() == 2: #South
            for w in self._map_data[self.current[1]+1:]:
                if w[self.current[0]] == '1':
                    return distance
                else:
                    distance += 1
                    continue
            return None
        elif self.get_direction() == 3: #North
            for w in self._map_data[:self.current[1]]:
                if w[self.current[0]] == '1':
                    distance = 0
                else:
                    distance += 1
                    continue
            return distance

    def get_enemies(self):
        """
        Return self.enemies

        It has a list which includes objects of each enemy.
        """
        return self._enemies

    def _set_enemy(map_data, x_len, y_len):
        size = x_len*y_len
        enemy_number = 0
        if x_len < 10 or y_len < 10 or size < 100:
            return []
        else:
            enemy_number = round(pow(size, 7/10))//20
            #print(enemy_number)
            candidates = []
            for y in range(1, y_len-1):
                for x in range(1, x_len-1):
                    wall_sides = 0

                    if map_data[y][x] == '1':
                        continue

                    if map_data[y][x+1] == '1':
                        wall_sides += 1
                    if map_data[y][x-1] == '1':
                        wall_sides += 1
                    if map_data[y+1][x] == '1':
                        wall_sides += 1
                    if map_data[y-1][x] == '1':
                        wall_sides += 1

                    if wall_sides == 3:
                        candidates.append((x, y))

            if len(candidates) <= enemy_number:
                return candidates

            enemies = []
            for i in range(enemy_number):
            #for i in range(1):
                idx = random.randint(0, len(candidates)-1)
                enemies.append(candidates.pop(idx))
            return enemies
                
    def _over_check(self):
        print(self.current, [e.get_enemy_position() for e in self._enemies])

        enemy_positions = [e.get_enemy_position() for e in self._enemies]
        enemy_directions = [e.get_direction() for e in self._enemies]
        my_position = self.current
        my_direction = self.get_direction()
        #print(f'DIRECT: {my_direction} {enemy_directions}')

        oppose = [idx
                    for idx, enemy_direction in enumerate(enemy_directions)
                    if (my_direction+enemy_direction) == 1 or (my_direction+enemy_direction) == 5
                ]

        if self.current in [e._position for e in self._enemies]:
            print('An enemy ate you: overwrapped')
            self._raise_game_over()
            return
        elif len(oppose) != 0:
            for e_idx in oppose:
                if enemy_directions[e_idx] == 0 and enemy_positions[e_idx][0]-1 == my_position[0] and enemy_positions[e_idx][1] == my_position[1]:
                    print('An enemy attacked you: l -> r')
                    self._raise_game_over()
                    self._label['image'] = self._empty
                    return
                elif enemy_directions[e_idx] == 1 and enemy_positions[e_idx][0]+1 == my_position[0] and enemy_positions[e_idx][1] == my_position[1]:
                    print('An enemy attacked you: r -> l')
                    self._raise_game_over()
                    self._label['image'] = self._empty
                    return
                elif enemy_directions[e_idx] == 2 and enemy_positions[e_idx][0] == my_position[0] and enemy_positions[e_idx][1]-1 == my_position[1]:
                    print('An enemy attacked you: t -> b')
                    self._raise_game_over()
                    self._label['image'] = self._empty
                    return
                elif enemy_directions[e_idx] == 3 and enemy_positions[e_idx][0] == my_position[0] and enemy_positions[e_idx][1]+1 == my_position[1]:
                    print('An enemy attacked you: b -> t')
                    self._raise_game_over()
                    self._label['image'] = self._empty
                    return
    
    def _raise_game_over(self):
        """########################################"""
        self._exit_label = tk.Label(self._root, image=self._resized_over, bg="white")
        self._exit_label.grid(row=self.y_len+2, column=0, columnspan=self.x_len)

        for action in self._actions:
            self._label.after_cancel(action)     

        self._text = tk.Label(self._root)
        self._text.grid(row=self.y_len+1, column=0, columnspan=4)

        for i in range(6):
            self._text.after(1000*i, func=self._over_message)
        """########################################"""

    def _over_message(self):
        self.__over_message()

    def __over_message(self):
        self._text['text'] = f'{self._timer} Seconds to end'
        self._timer -= 1
        if self._timer == -1 and self._auto_exit:
            sys.exit()

    def do(self):
        """
        This is a sample movement.
        You can try running this function.
        """
        random_move = [random.randint(0,3) for i in range(50)]
        for d in random_move:
            try:
                if d == 0 and self.current[0] != self.x_len -1:
                    self.move_east()
                elif d == 0 and self.current[0] == self.x_len -1:
                    continue

                if d == 1 and self.current[0] != 0:
                    self.move_west()
                elif d == 1 and self.current[0] == 0:
                    continue

                if d == 2 and self.current[1] != self.y_len - 1:
                    self.move_south()
                elif d == 2 and self.current[1] != self.y_len - 1:
                    continue

                if d == 3 and self.current[1] != 0:
                    self.move_north()
                elif d == 3 and self.current[1] != 0:
                    continue
            except:
                continue

    def _maze_create(self, _root):
        #grid creation
        for i in range(self.y_len):
            for j in range(1, self.x_len + 1):
                if i == 0 or i == self.y_len-1 or j == 1 or j == self.x_len:
                    #print(f"{x_len*i+j} : Black")
                    self._label = tk.Label(
                            _root,
                            #text=str(10*i+j),
                            bg="#000000",
                            fg="#FFFFFF",
                            padx=16,
                            pady=8
                        )
                #elif (10*i+j)%2 == 0:
                else:
                    #print(f"{x_len*i+j} : White")
                    self._label = tk.Label(
                            _root,
                            #text=str(10*i+j),
                            bg="#FFFFFF",
                            fg="#000000",
                            padx=16,
                            pady=8
                        )
                self._label.grid(row=i, column=j-1)
                self._grids.append(self._label)

    def __maze_create(self, _root, map_file):
        self._map_data, left, right = parse.parse_map(map_file)
        self.x_len = len(self._map_data[0])
        self.y_len = len(self._map_data)
        self.start = (0, left)
        self.dst = (self.x_len-1, right)
        self.current = self.start
        for r_idx, row in enumerate(self._map_data):
            for c_idx, e in enumerate(row):
                if e == '1': # Black
                    #print(f"{x_len*i+j} : Black")
                    self._label = tk.Label(
                            _root,
                            #text=str(10*i+j),
                            bg="#000000",
                            fg="#FFFFFF",
                            padx=16,
                            pady=8
                        )
                #elif (10*i+j)%2 == 0:
                else:
                    #print(f"{x_len*i+j} : White")
                    self._label = tk.Label(
                            _root,
                            #text=str(10*i+j),
                            bg="#FFFFFF",
                            fg="#000000",
                            padx=16,
                            pady=8
                        )
                self._label.grid(row=r_idx, column=c_idx)
                self._grids.append(self._label)

if __name__ == '__main__':
    root = tk.Tk()
    root.geometry("720x750")
    root.title("Maze Runner")
    root.resizable(True, True)
    #root.config(bg="#FFFFFF")

    maze = Maze(root)
    #maze.do()

    root.mainloop()
